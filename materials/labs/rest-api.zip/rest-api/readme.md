# REST API

## Requirements

- FastAPI
- Pandas

## Setup

```shell
pip install "fastapi[standard]"
```
